import pandas as pd

# =========================
# FILE PATHS
# =========================
INPUT_FILE = r"C:\Users\EL MECHKAT\Desktop\clinical_data.csv"
OUTPUT_FILE = r"C:\Users\EL MECHKAT\Desktop\protein_cleaned.csv"

# =========================
# LOAD TAB-SEPARATED FILE
# =========================
df = pd.read_csv(INPUT_FILE, sep="\t")

print("File loaded successfully")
print("Original columns:")
print(df.columns.tolist())

# =========================
# NORMALIZE COLUMN NAMES
# =========================
df.columns = (
    df.columns
    .str.strip()
    .str.lower()
    .str.replace(" ", "_")
)

print("Normalized columns:")
print(df.columns.tolist())

# =========================
# PROTEIN-RELATED COLUMNS
# =========================
protein_columns = [
    "patient_id",
    "sample_id",
    "er_status",
    "pr_status",
    "her2_status",
    "rppa_cluster",
    "tumor_stage",
    "pam50_subtype",
    "cancer_type_detailed"
]

# =========================
# KEEP ONLY EXISTING COLUMNS
# (safe selection)
# =========================
existing_columns = [c for c in protein_columns if c in df.columns]
df = df[existing_columns]

print("Kept columns:", existing_columns)

# =========================
# HANDLE MISSING VALUES
# =========================
df.fillna("Unknown", inplace=True)

# =========================
# NORMALIZE RECEPTOR STATUS
# =========================
def normalize_status(x):
    x = str(x).lower().strip()
    if x in ["positive", "pos", "1", "yes"]:
        return "Positive"
    if x in ["negative", "neg", "0", "no"]:
        return "Negative"
    return "Unknown"

for col in ["er_status", "pr_status", "her2_status"]:
    if col in df.columns:
        df[col] = df[col].apply(normalize_status)

# =========================
# REMOVE INVALID ROWS
# =========================
if "patient_id" in df.columns and "sample_id" in df.columns:
    df = df[
        (df["patient_id"] != "Unknown") &
        (df["sample_id"] != "Unknown")
    ]

# =========================
# REMOVE DUPLICATES
# =========================
if "patient_id" in df.columns and "sample_id" in df.columns:
    df.drop_duplicates(
        subset=["patient_id", "sample_id"],
        inplace=True
    )

# =========================
# SAVE CLEANED DATA
# =========================
df.to_csv(OUTPUT_FILE, index=False)

print("Protein data cleaned successfully.")
print("Saved to:", OUTPUT_FILE)
